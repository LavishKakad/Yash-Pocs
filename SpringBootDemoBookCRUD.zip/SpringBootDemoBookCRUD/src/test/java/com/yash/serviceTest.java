package com.yash;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.yash.model.Book;
import com.yash.repository.BookRepository;
import com.yash.service.BookServiceImpl;

@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest(classes = {serviceTest.class})
public class serviceTest {
	
	@Mock
	BookRepository brepo;
	
	@InjectMocks
	 BookServiceImpl bookService;
	
	@Test
	@Order(1)
	public void test_getAllBooks()
	{
		List<Book> books=new ArrayList<Book>();
		books.add(new Book(1,"cpp","lavish",200));
		books.add(new Book(2,"java","shubham",500));
		books.add(new Book(3,".Net","pranav",900));
		
		when(brepo.findAll()).thenReturn(books);
		assertEquals(3, bookService.getAllBooks().size()); 
	}
	
	@Test @Order(2)
	public void test_getBookById()
	{
		Optional<Book> book=Optional.of(new Book(1, "math", "sagar", 800));
		int bookId=1;
		
		when(brepo.findById(bookId)).thenReturn(book);
		assertEquals(bookId, bookService.getBookById(bookId).get().getBid());
		
	}
	
	@Test @Order(3)
	public void test_addBook()
	{
		Book b=new Book(4, "angular", "sagar", 670);
		
		when(brepo.save(b)).thenReturn(b);
		
		assertEquals(b, bookService.saveBook(b)); 
		
	}
	@Test @Order(4)
	public void test_updateBook()
	{
		Book b=new Book(4, "angular", "sagar", 670);
		
		when(brepo.save(b)).thenReturn(b);
		
		assertEquals(b, bookService.updateBook(b)); 
		
	}
	
	@Test @Order(5)
	public void test_deleteBook()
	{
		int id=1;
		bookService.deleteBook(id);
		
		verify(brepo,times(1)).deleteById(id);
	}
	
	

}
