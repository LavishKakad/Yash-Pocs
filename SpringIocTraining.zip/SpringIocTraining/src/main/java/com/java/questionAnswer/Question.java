package com.java.questionAnswer;


public class Question {
	private int qid;
	private String Qname;
	
	private Answer answer;

	public int getQid() {
		return qid;
	}

	public void setQid(int qid) {
		this.qid = qid;
	}

	public String getQname() {
		return Qname;
	}

	public void setQname(String qname) {
		Qname = qname;
	}

	
	public Answer getAnswer() {
		return answer;
	}

	public void setAnswer(Answer answer) {
		this.answer = answer;
	}

	public void show()
	{
		System.out.println("Question No :"+qid);
		System.out.println(Qname);
		answer.print();
	}
	
	

}
