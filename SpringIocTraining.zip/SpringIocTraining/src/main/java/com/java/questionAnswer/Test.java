package com.java.questionAnswer;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("question.xml");
		
		Question q = (Question) ctx.getBean("ques");
		q.show();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your ans no.");
		int s=sc.nextInt();
		if(s==1)
		{
			System.out.println("Your ans is correct");
		}
		else
			System.out.println("wrong ans");
		

	}

}
