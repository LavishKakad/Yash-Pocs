package com.java.questionAnswer;

import java.util.Iterator;
import java.util.List;

public class Answer {
	
	private List<String> ans;

	public List<String> getAns() {
		return ans;
	}

	public void setAns(List<String> ans) {
		this.ans = ans;
	}
	
	public void print()
	{
		/*
		 * Iterator<String> itr= ans.iterator(); while(itr.hasNext()) {
		 * System.out.println(itr.next()); }
		 */
		
		for(String l:ans)
		{
			System.out.println(l);
		}
	}
	

	
}
