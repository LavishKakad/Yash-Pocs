package com.java.Item;

public class ItemCategory {
	
	
	private String ItemName;

	public String getItemName() {
		return ItemName;
	}

	public void setItemName(String itemName) {
		ItemName = itemName;
	}
	
	
	
	  public void show() {
	  System.out.println("Item catagory item name is : "+ItemName); }
	 
}
