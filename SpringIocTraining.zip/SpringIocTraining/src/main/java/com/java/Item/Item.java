/*Create a two class one is item and second is item category
Category class will be injected in item class using setter method
Create the object of item class and print the detail of items along with the category name

Create a class where we will take input from user regarding questions
each question is having 4 answers which is injected through dependency object. 
User will choose correct answer and accordingly show the result if correct msg correct if wrong msg wrong
*/
package com.java.Item;

public class Item {
	private int itemId;
	private String itemName;
	
	private ItemCategory ic;

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public ItemCategory getIc() {
		return ic;
	}

	public void setIc(ItemCategory ic) {
		this.ic = ic;
	}

	

	
	  public void Print() 
	  {
		  System.out.println("Item id is : "+itemId);
		  System.out.println("Item name is : "+itemName);
		  ic.show(); 
	  }
	 
	
	

}
