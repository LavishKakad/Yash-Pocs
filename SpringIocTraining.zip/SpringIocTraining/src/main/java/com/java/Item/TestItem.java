package com.java.Item;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestItem {

	public static void main(String[] args) {

		ApplicationContext ctx=new ClassPathXmlApplicationContext("item.xml");
		
		Item i= (Item) ctx.getBean("item");
		
		
		i.Print();
	}

}
