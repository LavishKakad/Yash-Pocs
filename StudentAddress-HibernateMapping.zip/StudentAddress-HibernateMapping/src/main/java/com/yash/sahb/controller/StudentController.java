package com.yash.sahb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.sahb.model.Student;
import com.yash.sahb.serviceI.StudentService;

@RestController
public class StudentController {
	
	@Autowired
	StudentService ser;
	
	@RequestMapping("/save")
	public ResponseEntity<String> saveStudent(@RequestBody Student stu)
	{
		ser.saveStudent(stu);
		return new ResponseEntity<String>("data save successfully", HttpStatus.CREATED);
	}
	
	@GetMapping("/getAllData") 
	public ResponseEntity<List<Student>> showAllData()
	{
		 List<Student> showAllData = ser.showAllData();
		 
		 return new ResponseEntity<List<Student>>(showAllData, HttpStatus.OK);
		
	}

}
