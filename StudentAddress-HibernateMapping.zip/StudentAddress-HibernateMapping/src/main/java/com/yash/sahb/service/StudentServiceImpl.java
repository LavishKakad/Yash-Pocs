package com.yash.sahb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.sahb.model.Student;
import com.yash.sahb.repository.StudentRepository;
import com.yash.sahb.serviceI.StudentService;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	StudentRepository srepo;

	@Override
	public void saveStudent(Student stu) { 
		srepo.save(stu);
		
	}

	@Override
	public List<Student> showAllData() {
		
		return srepo.findAll();
	}
	
	
	
}
