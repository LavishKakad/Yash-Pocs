package com.yash.sahb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentAddressHibernateMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentAddressHibernateMappingApplication.class, args);
	}

}
