package com.yash.sahb.serviceI;

import java.util.List;

import com.yash.sahb.model.Student;

public interface StudentService {
	
	public void saveStudent(Student stu);
	
	public List<Student> showAllData();

}
