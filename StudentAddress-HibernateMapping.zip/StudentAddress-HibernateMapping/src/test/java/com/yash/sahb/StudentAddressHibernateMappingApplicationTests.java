package com.yash.sahb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentAddressHibernateMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
