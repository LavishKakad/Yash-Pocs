package com.yash.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.model.Student;

@Repository
public class StudentDao {
	
	@Autowired
	private JdbcTemplate jdbcTemp;
	
	public int save(Student s)
	{
		
		String query ="insert into student(name,fatherName,motherName,section,address,pinCode,city,mobNo,adharNo)"
			+ " values('"+s.getName()+"','"+s.getFatherName()+"','"+s.getMotherName()+"','"+s.getSection()+"','"+s.getAddress()+"','"+s.getPinCode()+"','"+s.getCity()+"','"+s.getMobNo()+"','"+s.getAdharNo()+"');";
		 int result = jdbcTemp.update(query);
		
		return result;
	}

}
