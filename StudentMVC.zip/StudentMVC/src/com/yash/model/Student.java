package com.yash.model;


public class Student {
	
	private int sid;
	private String name;
	private String fatherName;
	private String motherName;
	private String section;
	private String address;
	private String pinCode;
	private String city;
	private long mobNo;
	private long adharNo;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public long getMobNo() {
		return mobNo;
	}
	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}
	public long getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", name=" + name + ", fatherName=" + fatherName + ", motherName=" + motherName
				+ ", section=" + section + ", address=" + address + ", pinCode=" + pinCode + ", city=" + city
				+ ", mobNo=" + mobNo + ", adharNo=" + adharNo + "]";
	}
	
	

}
