package com.yash.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.yash.dao.StudentDao;
import com.yash.model.Student;

@Controller
public class MainController {
	
	@Autowired
	StudentDao sdao;
	
	@RequestMapping("/show")
	public String show()
	{
		System.out.println("inside show method");
		return "login";
	}
	
	@RequestMapping("/log")
	public String login()
	{
		System.out.println("inside login method");
		return "success";
	}
	
	@RequestMapping("/preregister")
	public String preRegister( Model m)
	{
		System.out.println("inside Preregister method");
		m.addAttribute("student",new Student());
		return "register";
	}
	
	
	@RequestMapping("/register")
	public String register(@ModelAttribute("student") Student s)
	{
		System.out.println("getting data from Register Page...");
		//System.out.println(s);
		
		  
		  System.out.println("Student Name ::"+s.getName());
		  System.out.println("Student Father Name ::"+s.getFatherName());
		  System.out.println("Student Mother Name ::"+s.getMotherName());
		  System.out.println("Student Section ::"+s.getSection());
		  System.out.println("Student Address ::"+s.getAddress());
		  System.out.println("Student Pin code ::"+s.getPinCode());
		  System.out.println("Student City ::"+s.getCity());
		  System.out.println("Student Mobile No. ::"+s.getMobNo());
		  System.out.println("Student Adhar No. ::"+s.getAdharNo());
		
		  sdao.save(s);
		
		  System.out.println(" Data Inserted Successfully..");
		return "success";
	}
	
	

}
