package removeWordFromString;

public class Test {

	public static void main(String[] args) {
		String str="I love my country";
		
		String s="";
		
		String [] str1=str.split(" ");
		
		 for (int i = 0; i < str1.length; i++) {
			System.out.print(str1[i]);
			 if(!str1[i].equals("my"))
			 {
				  s= s+str1[i];
				
			 }
			 //System.out.println();
		}
		 System.out.println();
		 System.out.println(s);

	}

}
