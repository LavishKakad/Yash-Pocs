package map;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public class sortMap {

	public static void main(String[] args) {

		Map<String, Integer> map = new TreeMap<String, Integer>();

		map.put("Lavish", 55);
		map.put("shubham", 35);
		map.put("pranav", 22);
		map.put("vishal", 45);
		map.put("sagar", 99);
		map.put("vedant", 32);

		Set<String> keySet = map.keySet();

		Collection<Integer> values = map.values();

		System.out.println();
		for (String key : keySet) {

			Integer integer = map.get(key);

			System.out.println("Key : " + key + " value :" + integer);

		}

	}

}
