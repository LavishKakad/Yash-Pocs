package map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class myMap {

	private static String string;

	public static void main(String[] args) {
	Map<Integer, String> m=new HashMap<Integer, String>();
	m.put(1, "Lavish");
	m.put(2, "Shubham");
	m.put(3, "vishal");
	
	//  METHOD :1
	 
	 /* for (Map.Entry m1 : m.entrySet()) {
	 * System.out.println(m1.getKey()+" "+m1.getValue()); }
	 ===============================================================================
	 */
	
	// METHOD :2
	 Set<Integer> keySet = m.keySet();
		//System.out.println(keySet);
		
		for(int keys : keySet)
		{
			String string = m.get(keys);
			System.out.println("key "+keys+ " values "+string);
		}
	
	 // =================================================================================
	 
		
	//METHOD :3
		//m.forEach((key,value)->System.out.println("key is "+ key+" , value is "+value) );
	//============================================================================================
	
	
	//METHOD :4
	
	 /* for (Integer a : m.keySet()) { //System.out.println(a);
		 * 
		 * String value=m.get(a); //System.out.println(value);
		 * 
		 * System.out.println(a+" "+value);
		 * 
		 * }
		 */
	//=============================================================================================	
		/*
		 * Iterator<Integer> itr=m.keySet().iterator();
		 * 
		 * while(itr.hasNext()) 
		 * { 
		 * int key=itr.next(); 
		 * System.out.println(key);
		 * System.out.println(m.get(key)); 
		 * }
		 */
	}

}
