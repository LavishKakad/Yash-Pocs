package java8Feature;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class consumerExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list=Arrays.asList(10,20,30,40,50,22,44);
		
		Consumer<Integer> c=new Consumer<Integer>() {
			
			@Override
			public void accept(Integer t) {
				System.out.println(t);
				
			}
		};
			list.stream().forEach(c);
	}

}
