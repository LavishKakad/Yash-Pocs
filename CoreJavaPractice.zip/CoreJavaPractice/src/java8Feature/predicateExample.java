package java8Feature;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class predicateExample {

	public static void main(String[] args) {
		
//		String[] str= {"lavish","shubham","sagar","vedant","shyam"};
//		
//		Predicate<String> p= name -> name.startsWith("s");
//		
//		for (String n : str) {
//			
//			if(p.test(n))
//			{
//				System.out.println(n);
//			}
//			
//		}

		
		List<Integer> list=Arrays.asList(10,20,30,40,22,55);
		
		Predicate<Integer> p=new Predicate<Integer>() {
			
			@Override
			public boolean test(Integer t) {
				if(t%10==0)
				{
					return true;
				}
				return false;
			}
		};
		
		List<Integer> filter = list.stream().filter(p).collect(Collectors.toList());
		System.out.println(filter);
		
	}

}
