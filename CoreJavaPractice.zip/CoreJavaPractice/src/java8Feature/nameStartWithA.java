package java8Feature;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class nameStartWithA {

	public static void main(String[] args) {
		
		//List<String> list=Arrays.asList("lavish","anupama","pranav","akash","akshay","shubham");
		
		List<String> list = new ArrayList<>(Arrays.asList("Austria","London", "Argentina", "Tokyo", "Australia"));
		
		List<String> collect = list.stream().filter(name->name.startsWith("A")).collect(Collectors.toList());
		System.out.println(collect);

	}

}
