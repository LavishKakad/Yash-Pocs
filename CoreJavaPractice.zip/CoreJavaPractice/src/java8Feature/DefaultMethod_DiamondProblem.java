package java8Feature;


class A{
	
	public void show()
	{
		System.out.println("from class A");
	}
}
interface B{
	 
	default public void show()
		{
			System.out.println("from class B");
		}
	
	
}

public class DefaultMethod_DiamondProblem extends A implements B{
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B b=new DefaultMethod_DiamondProblem();
		b.show();
		
		

	}

}
