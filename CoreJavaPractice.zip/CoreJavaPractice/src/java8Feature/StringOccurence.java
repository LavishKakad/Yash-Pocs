package java8Feature;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StringOccurence {

	public static void main(String[] args) {

		String str[]= {"lavish","shubham","danny","vishal","vishal","shubham","shubham"};
		
		List<String> list = Arrays.asList(str);
		
		Collections.sort(list);
		System.out.println(list);
		
		list.stream().anyMatch(n->n.contains(n));
		
		
		
		
//		Map<String, Integer> m=new HashMap<String, Integer>();
//		
//		for (int i = 0; i < str.length; i++) {
//			
//			//System.out.println(str[i]);
//			
//			if(m.containsKey(str[i]))
//			{
//				Integer value = m.get(str[i])+1;
//				m.put(str[i], value);
//			}
//			else
//			{
//				m.put(str[i], 1);
//			}
//				
//		}
//		System.out.println(m);
	}

}
