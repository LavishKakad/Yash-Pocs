package pairOfNoHavingSameSum;

public class Test {

	public static void main(String[] args) {
//		Write a code to find all pairs of integers from a given integer 
//		array such that the sum of these number is 12. [3,5,6,7,-1,4,2]
		
		int[] a= {3,5,6,7,-1,4,2};
		
		for (int i = 0; i < a.length; i++) {
			for (int j = 1; j < a.length; j++) {
				
				if(a[i]+a[j]==12)
				{
					System.out.println(a[i]+","+a[j]);
				}
				
			}
			
		}

	}

}
