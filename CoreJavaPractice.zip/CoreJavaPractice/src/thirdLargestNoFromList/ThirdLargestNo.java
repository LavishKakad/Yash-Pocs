package thirdLargestNoFromList;

public class ThirdLargestNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] a= {5,6,3,8,1,9,7};
		
		int temp=0;
		
		for (int i = 0; i < a.length-1; i++) {
			
			for (int j = 0; j < a.length; j++) {
				if(a[i]<a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
				
			}
			
		}
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
			
		}

	}

}
