package exceptionConcept;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Exception {
	
	/*If parent class exception throws an Exception then in therir child class no need to throws
	 * any exception, if we want to throws an exception then it should be same or there child child class
	 * exception we can throws */
	
	class parent{
		
		public void m1() throws IOException
		{
			System.out.println("in m1");
		}
	}
	
	class child extends parent{
		public void m1() throws FileNotFoundException
		{
			System.out.println("in m1");
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
