package datePrint;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import zigzacPattern.test;

public class Test {

	private Date startDate, endDate;

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		Date sd=new Date();
		sd.setDate(1);
		sd.setMonth(12);
		sd.setYear(1994);
		
		
		Date ed=new Date(1994, 10, 22);
		System.out.println(ed);
		SimpleDateFormat date=new SimpleDateFormat("dd-MM-yyyy");
		System.out.println(date.format(ed));
		
		Test t=new Test();
		t.setStartDate(sd);
		t.setEndDate(ed);
		
		System.out.println("start Date is :- "+t.getStartDate()+" and end Date is :- "+t.getEndDate());
		
		
		
	
	}

}
