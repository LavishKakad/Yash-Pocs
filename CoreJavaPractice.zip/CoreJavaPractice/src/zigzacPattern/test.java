package zigzacPattern;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="PAYPALISHIRING";
	    for(int j=1;j<=3;j++){
	        for(int p=1;p<=7;p++){
	            if(j==1 && p%2!=0){
	                if(j==1 && p==1){
	                    System.out.print(s.charAt(p-1));
	                }
	                else{
	                System.out.print(s.charAt((p*2)-2));
	                }
	            }
	            else if(p%2!=0 && j==3){
	                if((p*2)<=s.length()-1){
	                System.out.print(s.charAt((p*2)));
	                }
	            }
	            else if(j%2==0){
	                System.out.print(s.charAt((p*2)-1));
	            }
	            else{
	                System.out.print(" ");
	            }
	        }
	        System.out.println();
	    }


	}

}
