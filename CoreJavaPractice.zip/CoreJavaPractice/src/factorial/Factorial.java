package factorial;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		
		int fact=1;
		System.out.println("enter a no : ");
		Scanner sc=new Scanner(System.in);
		int no=sc.nextInt();
		
		for (int i = 1; i <= no; i++) {
			
			fact=fact*i;
			
		}
		System.out.println("factorial of "+no+" is : "+fact);
	}

}
