package removeDuplicate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicateFromString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String names[]={"anil", "Anil","Sunil", "Ajay", "Vijay", "Mahesh", "mahesh", "vijay","sunil", "ajay"};
		
		List<String>  list=Arrays.asList(names);
		List<String> list1=new ArrayList<String>();
		
		for (String string : list) {
			
			String upperCase = string.toUpperCase();
			list1.add(upperCase);
			
			//System.out.println(upperCase);	
			
		}
		
		Set<String> name=new HashSet<String>(list1);
		System.out.println(name);
		

	}

}
