package countFromString;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StringCount {

	public static void main(String[] args) {
		String str="hello my name is lavish lavish my name";
		
		String[] s = str.split(" ");
		
		int value=0;
		
		Map<String, Integer> map=new HashMap<String, Integer>();
		for (int i = 0; i < s.length; i++) {
			if(map.containsKey(s[i])) {
				value=map.get(s[i]);
				value=value+1;
				map.put(s[i], value);
					
			}
			else
			{
				map.put(s[i], 1);
			}
			
		}
		System.out.println(map);

		
		//OR
		
		List<String> list=Arrays.asList(s);
		
		Map<String, Integer> map1 = list.stream()
				.collect(Collectors.toMap(Function.identity(), v -> 1, Integer::sum));
		System.out.println(map1);
		

	}

}
