package print1to100UsingRecursion;

import java.util.stream.IntStream;

public class CountUpto100 {
	
	static void m1(int no) {
		
		if(no>=0)
		{
			m1(no-1);
			System.out.println(no);
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		m1(100);
		
		
		//Using Java 8
		//IntStream.range(1, 100).forEach(e -> System.out.println(e));

	}

}
