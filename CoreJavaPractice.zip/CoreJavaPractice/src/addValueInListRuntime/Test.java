package addValueInListRuntime;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

class user implements Serializable {
	int id;
	String name;

	public user(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

public class Test {

	public static void main(String[] args) {

		Map<String, Integer> map = new HashMap<String, Integer>();
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < 3; i++) {

			System.out.println("enter your name");
			String name = sc.next();
			System.out.println("enter your age");
			int age = sc.nextInt();
			map.put(name, age);

		}

		// System.out.println(map);

		// map.forEach((key,value)->System.out.println(key+" "+value));
		
		
		                   //OR//
		
		List<user> list=new ArrayList<user>();
		for (int i = 0; i < 3; i++)
		{
			System.out.println("enter your name");
			String name = sc.next();
			System.out.println("enter your age");
			int age = sc.nextInt();
			list.add(new user(age, name));
			
		}
		System.out.println(list);
		

	}

}
