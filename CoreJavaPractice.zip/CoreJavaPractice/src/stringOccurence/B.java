package stringOccurence;

import java.util.HashMap;
import java.util.Map;

public class B {

	public static void main(String[] args) {
		String s[] = { "BANANA", "APPLE", "ORANGE", "ORANGE", "BANANA", "BANANA", "APPLE", "BANANA", "ORANGE" };

		int count = 0;
		int count1 = 0;
		int count2 = 0;

		for (int i = 0; i < s.length - 1;i++) {
			for (int j = 0; j <= s.length - 1; j++) {
				if ("BANANA" == s[j]) {
					count++;

				}

				else if ("ORANGE" == s[j]) {
					count2++;

				} else {
					count1++;
				}

			}

			break;

		}
		System.out.println("BANANA : " + count);
		System.out.println("APPLE : " + count1);
		System.out.println("ORANGE : " + count2);
		
		System.out.println("==============================================");
		
		
		//OR
		
		Map<String, Integer> m=new HashMap<String, Integer>();
		int value=0;
		
		for (int i = 0; i < s.length; i++) {
			
			//System.out.println(s[i]);
			
			if(m.containsKey(s[i]))
			{
				value=m.get(s[i])+1;
				
				m.put(s[i], value);
			}
			else
			{
				m.put(s[i], 1);
			}
			
		}
		System.out.println(m);
	}

}
