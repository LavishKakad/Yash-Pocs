package customException;

 class AgeInvalidException extends Exception
 {
	 public AgeInvalidException( String msg) {
		super(msg);
	}
 }


public class Myexception {

	public static void main(String[] args) {
		
		int age=12;
		
		try {
			if(age<18)
			{
				throw new AgeInvalidException(" your Age not valid for voting");
			}
			else
			{
				System.out.println("you are eligible for voting");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
