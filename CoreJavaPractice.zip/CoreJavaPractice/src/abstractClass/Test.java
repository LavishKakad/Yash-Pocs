package abstractClass;

abstract class A{
	
	public void m1()
	{
		System.out.println("m1 method....");
	}
	 public void m2()
	{
		System.out.println("m2 method....");
	}
	
}

class B extends A{
	public void m3()
	{
		m1();
		m2();
		System.out.println("m3 method....");
	}

	
}


public class Test {

	public static void main(String[] args) {
		A a=new B();
		a.m1();
		a.m2();
		
		B b=new B();
		b.m2();

	}

}
