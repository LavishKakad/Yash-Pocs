package readDataFromFile;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Demo {

	public static void main(String[] args) throws FileNotFoundException {
		
		  File f=new File("C:\\Users\\lavish.kakad\\Desktop\\ABC.txt"); 
		  Scanner sc = new Scanner(f);
		  while(sc.hasNext()) 
		  { 
			  System.out.println(sc.nextLine());
		  }
		 
		
	}

}
