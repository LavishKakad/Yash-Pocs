package methodHiding;

class A{
	
	int a=10;
	public static void m1()
	{
		System.out.println("inside A");
	}
}

class B extends A{
	int a=20;
	public static void m1()
	{
		System.out.println("inside B");
	}
}

public class Test {

	public static void main(String[] args) {
		A a = new B();
		//a.m1();
		
		System.out.println(a.a);
		
		
	}

}
