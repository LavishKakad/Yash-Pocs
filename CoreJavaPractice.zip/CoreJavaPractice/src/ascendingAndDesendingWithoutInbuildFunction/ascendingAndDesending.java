package ascendingAndDesendingWithoutInbuildFunction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ascendingAndDesending {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "lavish";
		char[] cs = str.toCharArray();
		char temp = 0;
		for (int i = 0; i < cs.length; i++) {
			for (int j = 0; j < cs.length; j++) {
				if (cs[i] < cs[j]) { // ascending order
					// if (cs[i] > cs[j]) { // decending order
					temp = cs[i];
					cs[i] = cs[j];
					cs[j] = temp;
				}

			}

		}
		for (int i = 0; i < cs.length; i++) {
			System.out.print(cs[i]);

		}

	}

}
