package stringProgram;

public class CheckString {

	public static void main(String[] args) {

		String str="lavish";
		String str1="lavish";
		String str2=new String("lavish");
		
		if(str==str1)
		{
			System.out.println(true);
		}
		else
		{
			System.out.println(false);
		}
		if(str.equals(str1))
		{
			System.out.println(true);
		}
		else
		{
			System.out.println(false);
		}
		if(str==str2)
		{
			System.out.println(true);
		}
		else
		{
			System.out.println(false);
		}
		if(str.equals(str2))
		{
			System.out.println(true);
		}
		else
		{
			System.out.println(false);
		}
		
	}

}
