package tryc_catch_finallyBlock;

public class TryCatchFinally {
	
	int m1()
	{
		try 
		{
					
			System.out.println("in try block");	
			return 10;
					
		}
		catch (Exception e)
		{
			System.out.println("in catch block");	
			return 20;
		}
		finally 
		{
			System.out.println("in finally block");	
			return 30;	
		}
	}

	public static void main(String[] args) {
		TryCatchFinally obj=new TryCatchFinally();
		System.out.println(obj.m1());

	}

}
