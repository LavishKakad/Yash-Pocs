package spaceRemoveFromString;

public class Test {

	public static void main(String[] args) {
		String str="my name is lavish kakad ";
		
		String[] str1=str.split(" ");
		
		//System.out.println(str1[str1.length-2]);
		
		//OR
		
		for (int i = str1.length-2; i >=0 ; i--) {
			
			System.out.println(str1[i]);
			break;
		}

	}

}
