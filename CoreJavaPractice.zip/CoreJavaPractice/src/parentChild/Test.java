package parentChild;



class A{
	
	int a=10;
	int b=20;
	
	public String m1()
	{
		return "In class A m1-Method";
	}
	
}

class B extends A{
	
	int a=30;
	int b=40;

	public String m1()
	{
		return "In class B m1-Method";
	}
	
	
}

public class Test {
	public static void main(String[] args) {
		A a=new B();
		//B obj=(B)new A();//java.lang.ClassCastException
		B obj=(B) a; // solve ClassCastException
		System.out.println(obj.a); //30
		System.out.println(obj.b); //40
		System.out.println(obj.m1()); //In class B m1-Method
		
		
	}
	

}
