package palindrome;

public class NoPalindrom {

	public static void main(String[] args) {
		//i/p=121 o/p=palindrome
		
		int no=121;
		int sum=0;
		int temp=no;
		int remain;
		
		while(no>0)
		{
			remain=no%10; 
			sum=(sum *10)+remain;
			no=no/10;
				
		}
		if(temp==sum)
		{
			System.out.println("palindrome");
		}
		else
		{
			System.out.println("not palindrome");
		}
	}

}
