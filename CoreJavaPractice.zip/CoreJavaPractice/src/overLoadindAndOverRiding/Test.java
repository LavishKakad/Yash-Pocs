package overLoadindAndOverRiding;

class A {

	public void m1() {
		int x = 10;
		System.out.println(x);
	}
	public void m2(int a,int b,int c) {
		a = 20;b=30;c=40;
		System.out.println(a+" "+b+" "+c);
	}
}

class B extends A {

	@Override
	public void m1() {
		int x = 20;
		System.out.println(x);
	}

	public void m2(int a) {
		a = 20;
		System.out.println(a);
	}

	public void m2(int a, int b) {
		a = 20;
		b = 30;
		System.out.println(a + " " + b);
	}

}

public class Test {

	public static void main(String[] args) {
//		B obj = new B();
//		obj.m1();
//		obj.m2(400);
//		obj.m2(500, 600);

		A aobj = new B();
		aobj.m1();

	}

}
