
//Shubham Tembhare BNYM interview question
package accessModifier;

class A{
	
	private int x()
	{
		System.out.println("In A class x method");
		return 1;
	}
}

  class B extends A{
	
	public int x()
	{
		System.out.println("In B class x method");
		return 2;		}
}

public class AccessModifier {
	
	public static void main(String[] args) {
		A a=new B();
		//a.x();

	}

}
