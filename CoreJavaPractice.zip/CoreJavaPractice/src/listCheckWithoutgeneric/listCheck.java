package listCheckWithoutgeneric;

import java.util.ArrayList;
import java.util.List;

class Employee {

	private String name, address;

	public Employee(String name, String address) {
		super();
		this.name = name;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", address=" + address + "]";
	}

	Employee() {
		super();
	}

}

public class listCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List list = new ArrayList();

		list.add(10);
		list.add("lavish");
		list.add(20);
		list.add(new Employee("shubham", "Amravati"));

		for (Object as : list) {

			if (as instanceof Integer) {

				System.out.println(as);
			}
			if (as instanceof String) {

				System.out.println(as);
			}
			if (as instanceof Employee) {

				Employee e = (Employee) as;
				System.out.println(e.getName());
			}

		}

	}

}
