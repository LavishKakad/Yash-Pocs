package singletonPattern;

public class MySingleton {

	private static  MySingleton ms;

	private MySingleton() {

	}

	public static  MySingleton m1() {
		if (ms == null) {
			ms = new MySingleton();
		}
		return ms;
	}

	public static void main(String[] args) {

		MySingleton s = MySingleton.m1();
		MySingleton s0 = MySingleton.m1();
		MySingleton s1 = new MySingleton();
		MySingleton s2 = new MySingleton();

		System.out.println(s.hashCode());
		System.out.println(s0.hashCode());
		System.out.println(s1.m1().hashCode());
		System.out.println(s2.m1().hashCode());

	}

}
