package evenOddmultiplicationAndSum;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list=Arrays.asList(2,3,5,6,4,7,8);
		
		//List<Integer> list1=new ArrayList<Integer>();
		
		int sum=0;
		
		for (int i = 0; i < list.size(); i++) {
			//System.out.println("index no :-"+i +"value :-"+list.get(i));
			if(i==0)
			{
				//list1.add(list.get(0));
				sum=sum+list.get(0);
			}
		else if(i %2==0)
			{
				int a=list.get(i)*3;
				//list1.add(a);
				sum=sum+a;
			}
			else
			{
				int a=list.get(i)*2;
				//list1.add(a);
				sum=sum+a;
			}
			
		}
		
		//System.out.println(list1);
		
//		for (Integer integer : list1) {
//			sum=sum+integer;	
//		}
		System.out.println("sum is :-> "+sum);
	}

}
