package lenghOfStringFromList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LengthOfString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> list= Arrays.asList("lavish","shubham","ram");
		List<Integer> len=new ArrayList<Integer>();
		
		/*
		 * for (int i = 0; i < list.size(); i++) { //System.out.println(list.get(i));
		 * 
		 * int length = list.get(i).length(); len.add(length); }
		 * System.out.println(len);
		 */
		
		// 2nd way:-
		
		/*
		 * for (String str : list) {
		 * 
		 * System.out.println(str); int length = str.length(); len.add(length); }
		 * System.out.println(len);
		 */
	}

}
