package duplicateFind;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class A {

	public static void main(String[] args) {

		Integer arr[]= {1,2,1,3,4,4};
		
		/*
		 * for (int i = 0; i < arr.length-1; i++) 
		 * {
		 *  for (int j = i+1; j < arr.length; j++) {
		 * 
		 * if(arr[i] == arr[j]) { System.out.println(arr[i]);
		 * 
		 * }
		 * 
		 * }
		 * 
		 * }
		 */
		Set<Integer> aa=new HashSet<Integer>();
		 Set<Integer> collect = Arrays.stream(arr).filter(n-> !aa.add(n)).collect(Collectors.toSet());
		 System.out.println(collect);
		
		
	}

}
