package duplicateFind;



public class DuplicateString {

	public static void main(String[] args) {
		
		String str="test test new test test java qwert";
		
		String[] s = str.split(" ");
		
		for (int i = 0; i < s.length-1; i++) {
			
				if(!s[i].equals(s[i+1]))
				{
					System.out.println(s[i+1]);
					break;
				}		
	
		}
		
	}

}
