package JohndeereInterview;

class Interview
{
	int id;
	String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}


public class TestStr {

	public static void yourmethod(){
        Interview interview=new Interview();
        interview.setName("old interview");
        change(interview);
       System.out.println(interview.getName());
    }
    public static void change(Interview interview){
        interview=new Interview();
        interview.setName("New Interview");
        //System.out.println(interview.getName());
        
    }
    public static void main(String[] args) {
            yourmethod();
    }


}
