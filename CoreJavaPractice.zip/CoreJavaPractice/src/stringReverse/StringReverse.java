package stringReverse;

public class StringReverse {
	
	public String m1( String s)
	{
		//String s="Lavish";
		char[] a=s.toCharArray();
		for(int i=a.length-1;i>=0;i--)
		{
			System.out.print(a[i]);
		}
		
		return s;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringReverse ss=new StringReverse();
		ss.m1("Shubham");

	}

}
