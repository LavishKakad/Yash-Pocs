package fabonacci;

public class FabonacciSeries {

	public static void main(String[] args) {
		
		//o/p-->0,1,1,2,3,5,8,....
		
		int a=0,b=1;
		int no=5,result;
		
		System.out.println(a+" "+b);
		for (int i = 1; i < no; i++) {
			
			result=a+b;
			System.out.println(result);
			a=b;
			b=i;
			
		}

	}

}
