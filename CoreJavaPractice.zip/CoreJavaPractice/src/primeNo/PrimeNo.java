package primeNo;

public class PrimeNo {

	public static void main(String[] args) {

		int no = 17;
		int count = 1;

		for (int i = 2; i <= no - 1; i++) {

			if (no % i == 0) {
				count++;
			}

		}

		if (count == 1) {
			System.out.println(no + " is prime no");
		} else
			System.out.println(no + " is NOT prime no");

		// Second nd Way:-

		/*
		 * int count2 = 0;
		 * 
		 * for (int i = 1; i <= no; i++) {
		 * 
		 * if(no%i==0) { count2++; }
		 * 
		 * 
		 * } if(count2==2) { System.out.println("prime"); } else {
		 * System.out.println("not prime"); }
		 */

	}

}
