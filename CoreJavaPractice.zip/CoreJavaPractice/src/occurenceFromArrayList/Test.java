package occurenceFromArrayList;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Test {

	public static void main(String[] args) {
		
		List<Integer> list=Arrays.asList(1,1,2,2,2,2,3,2,1,4,5,5,6,4,7,5,8);
		
		Map<Integer, Integer> m=new HashMap<Integer, Integer>();
		
		
		for (Integer itr : list) {
			
			if(m.containsKey(itr))
			{
				m.put(itr, m.get(itr)+1);
			}
			else
			{
				m.put(itr, 1);
			}
			
		}
		
		System.out.println(m);
		
		
		//OR
	
//		for (int i = 0; i < list.size(); i++) {
//			
//			if(m.containsKey(list.get(i)))
//			{
//				m.put(list.get(i), m.get(list.get(i))+1);
//			}
//			else
//			{
//				m.put(list.get(i),1);
//			}
//			
//		}
//		System.out.println(m);

	}

}
