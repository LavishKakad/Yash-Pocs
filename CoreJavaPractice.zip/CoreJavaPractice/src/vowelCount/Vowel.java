package vowelCount;

public class Vowel {

	public static void main(String[] args) {
		String str="my name is lavish eu AEU ";
		
		String str1=str.toLowerCase();
		
		char[] c=str1.toCharArray();
		
		int count=0;
		
		for (int i = 0; i < c.length; i++) {
			
			if(c[i]=='a'||c[i]=='e'||c[i]=='i'||c[i]=='o'||c[i]=='u' )
			{
				count++;
			}	
		}
		System.out.println("vowels count are : "+count); 
	}

}
