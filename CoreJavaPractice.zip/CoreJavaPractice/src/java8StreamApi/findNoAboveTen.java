package java8StreamApi;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class findNoAboveTen {

	public static void main(String[] args) {
		
		List<Integer> l1=Arrays.asList(1,2,4,4,10,20,30,50,5,7,8,90);
		
		 List<Integer> collect = l1.stream().filter(no->no>10).collect(Collectors.toList());
		
		System.out.println(collect);
		
		
		
		
		
		/*
		 * List<Integer> collect1 =
		 * l1.stream().map(no->no*no).distinct().collect(Collectors.toList());
		 * System.out.println(collect1);
		 */
		 

	}

}
