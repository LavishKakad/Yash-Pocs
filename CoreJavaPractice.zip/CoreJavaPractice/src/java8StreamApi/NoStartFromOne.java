package java8StreamApi;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class NoStartFromOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list=Arrays.asList(10,3,4,101,111,167,89,46,55);
		
		 list.stream().filter(no-> no.toString().startsWith("1")).forEach(System.out::println);
		
		

	}

}
