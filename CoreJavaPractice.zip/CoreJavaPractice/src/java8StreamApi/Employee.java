package java8StreamApi;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Employee {
	
	private String name,country;
	private int salary;
	

	public Employee(String name, String country, int salary) {
		super();
		this.name = name;
		this.country = country;
		this.salary = salary;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public int getSalary() {
		return salary;
	}


	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	


	@Override
	public String toString() {
		return "Employee [name=" + name + ", country=" + country + ", salary=" + salary + "]";
	}


	public static void main(String[] args) {
		List<Employee> emp=new ArrayList<Employee>();
		List<Employee> emp1=new ArrayList<Employee>();

		
		emp.add(new Employee("lavish", "india", 1234));
		emp.add(new Employee("shubham", "india", 765));
		emp.add(new Employee("vishal", "pak", 5555));
		emp.add(new Employee("danny", "china", 7777));
		
//		for (Employee employee : emp) {
//			//System.out.println(employee);
//			
//			if(employee.getCountry().equals("india"))
//			{
//				emp1.add(employee);
//			}
//		
//				
//		}
//		System.out.println(emp1);
	
		//*****************************************************************
		
//		 emp.stream().map(e -> {
//			if(e.getCountry().equals("pak")){
//			
//				emp1.add(e);
//			}
//			return e;
//			}).collect(Collectors.toList());
//		
//		System.out.println(emp1);
		
		//*****************************************************************
		
		 emp.stream().filter(e -> e.getCountry().equals("india")).forEach(System.out::println);
		 
		 //****************************************************************
		
		List<Employee> collect = emp.stream().filter(e -> e.getCountry().equals("india")).collect(Collectors.toList());
		System.out.println(collect);

	}

}
