package java8StreamApi;

import java.util.List;
import java.util.Optional;

public class findMinMax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list= List.of(10,5,30,6,22,66,87,33,89,12);
		
		Optional<Integer> min = list.stream().min((x,y)-> x.compareTo(y));
		
		System.out.println(min);
		
        Optional<Integer> max = list.stream().max((x,y)-> x.compareTo(y));
		
		System.out.println(max);

	}

}
