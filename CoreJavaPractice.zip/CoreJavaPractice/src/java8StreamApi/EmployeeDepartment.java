package java8StreamApi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.function.ToDoubleFunction;
import java.util.stream.Collectors;

public class EmployeeDepartment {

	private int id;
	private String ename, deptName, gender;
	private double salary;

	public EmployeeDepartment(int id, String ename, String deptName, String gender, double salary) {
		super();
		this.id = id;
		this.ename = ename;
		this.deptName = deptName;
		this.gender = gender;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public String getEname() {
		return ename;
	}

	public String getDeptName() {
		return deptName;
	}

	public String getGender() {
		return gender;
	}

	public double getSalary() {
		return salary;
	}
	

	@Override
	public String toString() {
		return "EmployeeDepartment [id=" + id + ", ename=" + ename + ", deptName=" + deptName + ", gender=" + gender
				+ ", salary=" + salary + "]";
	}

	public static void main(String[] args) {
		
		List<EmployeeDepartment> elist=new ArrayList<EmployeeDepartment>();
		elist.add(new EmployeeDepartment(101, "lavish", "IT", "male", 10000));
		elist.add(new EmployeeDepartment(102, "shubham", "IT", "male", 13000));
		elist.add(new EmployeeDepartment(103, "vishal", "HR", "male", 50000));
		elist.add(new EmployeeDepartment(104, "sanket", "IT", "male", 60000));
		elist.add(new EmployeeDepartment(105, "Rani", "HR", "Female", 80000));
		
		
		//O/P:-
		//HR :: Max Salary =80000
		//IT :: Max Salary =60000
		
			
		//elist.stream().map(q -> q.getDeptName()).distinct().collect(Collectors.toList()).forEach(System.out::println);
		
		/*
		 * Optional<Double> m = elist.stream().map(e->e.getSalary()).max((a,b) ->
		 * a.compareTo(b)); System.out.println(m);
		 */
		
		//First way:-
//		Map<String, Optional<EmployeeDepartment>> emp = elist.stream().collect(Collectors.groupingBy(EmployeeDepartment::getDeptName,
//				Collectors.maxBy(Comparator.comparingDouble(EmployeeDepartment::getSalary))));
//		
//		Collection<Optional<EmployeeDepartment>> values = emp.values();
//		values.stream().map(name -> name.get().getDeptName()+" "+name.get().getSalary()).forEach(System.out::println);
	
		
		//Second way:-
//		Map<String, EmployeeDepartment> employee = elist.stream().collect(Collectors.groupingBy(EmployeeDepartment::getDeptName,
//		Collectors.collectingAndThen(Collectors.maxBy(Comparator.comparingDouble(EmployeeDepartment::getSalary)), Optional::get)));
//		
//		for(Map.Entry<String,EmployeeDepartment> m1: employee.entrySet())
//		{
//			System.out.println(m1.getKey()+" "+m1.getValue().getSalary());
//		}
		
	}

	}

