package concurrentModification;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class MyException {

	public static void main(String[] args) {
		
		List<Integer> l=new ArrayList<Integer>();
		
		l.add(1);
		l.add(2);
		l.add(3);
		
		for (Integer a : l) {
			System.out.println(a);
			l.add(4);
		}
		
	
		/*
		 * Iterator<Integer> itr=l.iterator(); 
		 * while (itr.hasNext()) 
		 * { 
		 * Integer i1 = itr.next();
		 *  System.out.println(i1);
		 *   l.add(4);
		 * 
		 * }
		 */

	}

}
