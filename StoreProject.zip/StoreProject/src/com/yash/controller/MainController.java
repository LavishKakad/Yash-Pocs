package com.yash.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
	
	@RequestMapping("/show")
	public String show()
	{
		System.out.println("inside show method");
		return "show";
	}

}
