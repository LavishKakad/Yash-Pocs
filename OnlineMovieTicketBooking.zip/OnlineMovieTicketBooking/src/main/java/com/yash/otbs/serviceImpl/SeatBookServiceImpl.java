package com.yash.otbs.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.otbs.pojo.SeatBook;
import com.yash.otbs.repository.SeatBookrepository;
import com.yash.otbs.service.SeatBookService;


@Service
public class SeatBookServiceImpl implements SeatBookService{
	
	@Autowired
	SeatBookrepository seatBookrepo;

	@Override
	public SeatBook bookseat(SeatBook seatBook) {
		return seatBookrepo.save(seatBook);
		
	}

	@Override
	public SeatBook findBySeatId(int sid) {
		// TODO Auto-generated method stub
		return seatBookrepo.findBySid(sid);
	}

}
