package com.yash.otbs.service;

import com.yash.otbs.pojo.SeatBook;


public interface SeatBookService {

	public SeatBook bookseat(SeatBook seatBook);

	public SeatBook findBySeatId(int sid);
}
