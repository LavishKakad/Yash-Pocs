package com.yash.otbs.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yash.otbs.pojo.movieDetails;

@Repository
public interface MovieDetailRepository extends JpaRepository<movieDetails, Integer> {

}
