package com.yash.otbs.service;

import java.util.List;

import com.yash.otbs.pojo.SeatBook;
import com.yash.otbs.pojo.User;

public interface UserService {
	public void userSave(User user);
	public User findUandP(String uname,String password);
	public List<User> getAllData();
	
	public User findByUserId(int uid);

}
