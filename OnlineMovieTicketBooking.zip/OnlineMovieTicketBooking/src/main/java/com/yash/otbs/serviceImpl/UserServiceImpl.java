package com.yash.otbs.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.otbs.pojo.SeatBook;
import com.yash.otbs.pojo.User;
import com.yash.otbs.repository.UserRepository;
import com.yash.otbs.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository userrepo;
	
	public void userSave(User user)
	{
		userrepo.save(user);
	}

	@Override
	public User findUandP(String uname, String password) {
		return userrepo.findByUnameAndPassword(uname, password);
		
	}

	@Override
	public List<User> getAllData() {
		
		return userrepo.findAll();
	}

	@Override
	public User findByUserId(int uid) {
		
		return userrepo.findByUid(uid); 
	}



}
