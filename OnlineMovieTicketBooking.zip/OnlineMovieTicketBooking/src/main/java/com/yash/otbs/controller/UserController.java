package com.yash.otbs.controller;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.yash.otbs.pojo.User;
import com.yash.otbs.pojo.movieDetails;
import com.yash.otbs.repository.MovieDetailRepository;
import com.yash.otbs.service.MovieDetailsService;
import com.yash.otbs.service.UserService;

@Controller
//@RestController
public class UserController {
	
	@Autowired
	UserService userserv;
	
	@Autowired
	MovieDetailsService movieDetailServ;
	
	@RequestMapping("/")
	public String login()
	{
		System.out.println("in login");
		return "login";
	}
	
	@RequestMapping("/log")
	public String afterLogin(@ModelAttribute User u,Model m)
	{
		
		 User auth = userserv.findUandP(u.getUname(), u.getPassword());
		System.out.println(u.getUname()+" "+u.getPassword());
		
		
		if(Objects.nonNull(auth))
		{
			System.out.println("user Login...");
			List<movieDetails> showAllMovies = movieDetailServ.showAllMovies();
			m.addAttribute("allMovie", showAllMovies);
			System.out.println("in user controller "+auth.getUid());
			m.addAttribute("user", auth);
			return "welcomeUser";
		}
		else if(u.getUname().equalsIgnoreCase("admin") && u.getPassword().equalsIgnoreCase("admin"))
		{
			System.out.println("Admin Login...");
			return "welcomeAdmin";
		}
		else
		return "login";
	}
	
	@RequestMapping("/addNewUser")
	public String registerPage()
	{
		System.out.println("in register page..");
		return "register";
	}
	
	@RequestMapping("/register")
	public String addNewUser(@ModelAttribute("user") User user)
	{
		System.out.println(" new user register sucessfully..");
		userserv.userSave(user);
		return "login";
	}
	

}
