package com.yash.otbs.pojo;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
public class movieDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mid;
	private String movieName;
	private String starCast;
	private String realeaseDate;
	
	
	public movieDetails() {  
		super(); 
		// TODO Auto-generated constructor stub
	}



	
	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getStarCast() {
		return starCast;
	}

	public void setStarCast(String starCast) {
		this.starCast = starCast;
	}

	public String getRealeaseDate() {
		return realeaseDate;
	}

	public void setRealeaseDate(String realeaseDate) {
		this.realeaseDate = realeaseDate;
	}

	@Override
	public String toString() {
		return "movieDetails [mid=" + mid + ", movieName=" + movieName + ", starCast=" + starCast + ", realeaseDate="
				+ realeaseDate + "]";
	}
	
	
	
	

}
