package com.yash.otbs.service;

import java.util.List;

import com.yash.otbs.pojo.movieDetails;

public interface MovieDetailsService {
	
	public List<movieDetails> showAllMovies();
	
	public void saveMovie(movieDetails movie);

}
