package com.yash.otbs.controller;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.yash.otbs.pojo.SeatBook;
import com.yash.otbs.pojo.User;
import com.yash.otbs.service.SeatBookService;
import com.yash.otbs.service.UserService;

@Controller
public class SeatBookController {
	
	@Autowired
	SeatBookService seatBookServ;
	
	@Autowired
	UserService userserv;
	
	
	
	@RequestMapping("/seatBooking/{uid}")
	public String seatBooking(@PathVariable (value = "uid") int uid,Model m)
	{
		System.out.println("seat controller user "+uid);
		 
		User findByUserId = userserv.findByUserId(uid);
		m.addAttribute("user",findByUserId);
		m.addAttribute("seatBook",new SeatBook());
		
		System.out.println("in seat booking controller"+findByUserId);
		return "bookSeats";
	}
	@RequestMapping("/bookSeat")
	public String bookSeatInMovie(@ModelAttribute SeatBook seatBook,Model m)
	{
		int userId=seatBook.getSid();
		
		seatBook.setSid(0);
		SeatBook ss=seatBookServ.bookseat(seatBook);
		User userDeatails = userserv.findByUserId(userId);
		userDeatails.setSeatBooks(ss);
		
		userserv.userSave(userDeatails);
		System.out.println(ss);
		if(seatBook.getTimeSloat().equals("9:00 a.m-12:00 p.m")) {
			seatBook.setPrice(200);
		}else if(seatBook.getTimeSloat().equals("12:00 p.m-3:00 p.m")) {
			seatBook.setPrice(300);
		}else if(seatBook.getTimeSloat().equals("3:00 p.m-6:00 p.m")) {
			seatBook.setPrice(400);
		}
		Double totalPrice=0.0;
		if(seatBook.getPrice()>0) {
			totalPrice=Double.parseDouble(ss.getSeatNo())*ss.getPrice();
			seatBook.setTotalPrice(totalPrice);
		}
		
		
		m.addAttribute("seatBook",ss);
		System.out.println("In Payment");
		
		return "payment";
	}
	
	@RequestMapping("/payticketes")
	public String payTicketForMovie(@ModelAttribute SeatBook seatBook,Model m)
	{
		int userId=seatBook.getSid();
		
		System.out.println(seatBook);
		
//		seatBook.setSid(0);
//		SeatBook ss=seatBookServ.bookseat(seatBook);
		
		
		SeatBook seatBookDetails = seatBookServ.findBySeatId(seatBook.getSid());
		System.out.println(seatBookDetails);
		seatBookDetails.setPrice(seatBook.getPrice());		
		seatBookDetails.setTotalPrice(seatBook.getTotalPrice());		
		seatBookServ.bookseat(seatBookDetails);
		
		return "login";
	}

}
