package com.yash.otbs.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.otbs.pojo.movieDetails;
import com.yash.otbs.repository.MovieDetailRepository;
import com.yash.otbs.service.MovieDetailsService;

@Service
public class MovieDetailsServiceImpl implements MovieDetailsService {
	
	@Autowired
	MovieDetailRepository movieDetailRepo;

	@Override
	public List<movieDetails> showAllMovies() {
		
		List<movieDetails> findAllMovie = movieDetailRepo.findAll();
		
		return findAllMovie;
	}

	@Override
	public void saveMovie(movieDetails movie) {
	
		movieDetailRepo.save(movie);
	}

	
}
