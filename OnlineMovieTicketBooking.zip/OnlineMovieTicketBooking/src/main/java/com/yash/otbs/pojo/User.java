package com.yash.otbs.pojo;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int uid;
	private String uname,email,password;
	private String mobileNo,gender; 
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "s_id") 
	private SeatBook seatBooks;
	 
	
	public SeatBook getSeatBooks() {
		return seatBooks;
	}
	
	public void setSeatBooks(SeatBook seatBooks) {
		this.seatBooks = seatBooks;
	}
	/*
	 * @OneToMany(cascade = CascadeType.ALL,mappedBy = "user") private Set<SeatBook>
	 * seatBooks;
	 * 
	 * public Set<SeatBook> getSeatBooks() { return seatBooks; } public void
	 * setSeatBooks(Set<SeatBook> seatBooks) { this.seatBooks = seatBooks; }
	 */
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "User [uid=" + uid + ", uname=" + uname + ", email=" + email + ", password=" + password + ", mobileNo="
				+ mobileNo + ", gender=" + gender + ", seatBooks=" + seatBooks + "]";
	}

	
	
}
