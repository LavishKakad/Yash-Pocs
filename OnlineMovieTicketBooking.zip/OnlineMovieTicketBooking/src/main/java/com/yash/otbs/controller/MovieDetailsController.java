package com.yash.otbs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.yash.otbs.pojo.User;
import com.yash.otbs.pojo.movieDetails;
import com.yash.otbs.service.MovieDetailsService;

@Controller
public class MovieDetailsController {
	
	@Autowired
	MovieDetailsService movieDetailServ;
	 
	@GetMapping("/addMovieByAdmin")
	public String saveMovie()
	{
		return "addMovie";
	}
	@PostMapping("/savemovie")
	public String SaveByAdmin(movieDetails movie)
	{
		movieDetailServ.saveMovie(movie);
		
		return "welcomeAdmin";
	}
	
	
	

}
