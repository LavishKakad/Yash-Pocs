package com.yash.fos.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.fos.model.Item;
import com.yash.fos.model.User;
import com.yash.fos.service.ItemService;

@RestController
@CrossOrigin("*")
public class ItemController {
	
	@Autowired
	ItemService iserv;
	
	@GetMapping("/getAllItems")
	public List<Item> getAllItems()
	{
		List<Item> a=iserv.getAllItem();
		List<Item> it=a.stream().filter(i->i.isIsdeleted()==false).collect(Collectors.toList());
		return it;
	}
	
	@PostMapping("/saveItem")
	public Item saveItem(@RequestBody Item item)
	{
		System.out.println(item);
		return iserv.saveItem(item);	
	}
	
	@DeleteMapping("/deleteItem/{id}")
	public String deleteItem(@PathVariable int id)
	{
		return iserv.deleteItem(id);
	}
	
	@PutMapping("/updateItem")
	public Item updateItem(@RequestBody Item item)
	{
		return iserv.updateItem(item);
	}
	
	@GetMapping("/getItemById/{id}")
	public Optional<Item> getSingleItem(@PathVariable int id)
	{
		return iserv.getSingleItem(id);
	}
	
	@GetMapping("/updateItemFlag/{id}")
	public Item updateItemFlag(@PathVariable int id)
	{
		Optional<Item> I=iserv.getSingleItem(id);
		Item t=I.get();
		t.setIsdeleted(true);
		return iserv.saveItem(t);
	}

}
