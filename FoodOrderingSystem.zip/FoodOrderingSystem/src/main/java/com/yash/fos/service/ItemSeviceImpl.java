package com.yash.fos.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.fos.model.Item;
import com.yash.fos.repository.ItemRepository;

@Service
public class ItemSeviceImpl implements ItemService {
	
	@Autowired
	ItemRepository irepo;

	@Override
	public List<Item> getAllItem() {
		
		return irepo.findAll();
	}

	@Override
	public Item saveItem(Item item) {
		
		return irepo.save(item);
	}

	@Override
	public String deleteItem(int id) {
		
		 irepo.deleteById(id);
		 return "Item having Id "+id+" deleted successfully";
	}

	@Override
	public Item updateItem(Item item) {
		
		return irepo.save(item);
	}

	@Override
	public Optional<Item> getSingleItem(int id) {
		
		return irepo.findById(id);
	}

}
