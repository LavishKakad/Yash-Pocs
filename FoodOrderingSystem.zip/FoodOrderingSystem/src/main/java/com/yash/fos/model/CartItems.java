package com.yash.fos.model;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CartItems {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private double price;
	private int quantity;
	private double total;
	private String image;

	private int uid;
	private int Iid;
	

	public int getIid() {
		return Iid;
	}


	public void setIid(int iid) {
		Iid = iid;
	}


	public int getUid() {
		return uid;
	}


	public void setU_id(int uid) {
		this.uid = uid;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public double getTotal() {
		return total;
	}


	public void setTotal(double total) {
		this.total = total;
	}


	@Override
	public String toString() {
		return "CartItems [id=" + id + ", name=" + name + ", price=" + price + ", quantity=" + quantity + ", total="
				+ total + ", image=" + image + ", uid=" + uid + ", Iid=" + Iid + "]";
	}
	
	

}
