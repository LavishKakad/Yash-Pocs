package com.yash.fos.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.fos.model.User;
import com.yash.fos.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository urepo;

	@Override
	public List<User> getAllData() {
		
		return urepo.findAll();
	}

	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return urepo.save(user);
	}

	@Override
	public String deleteUser(int id) {
		urepo.deleteById(id);
		return "User having Id "+id+" deleted successfully";
	}

	@Override
	public Optional<User> getUserById(int id) {
		
		return urepo.findById(id);
	}

	@Override
	public User updateUser(User user) {
		
		return urepo.save(user);
	}

	@Override
	public User showPerticularUser(String uname, String upassword) {
	
		return urepo.findByUnameAndUpassword(uname, upassword);
	}

}
