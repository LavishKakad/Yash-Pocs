package com.yash.fos.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.fos.model.CartItems;
import com.yash.fos.model.Item;
import com.yash.fos.model.User;
import com.yash.fos.service.CartItemsService;
import com.yash.fos.service.ItemService;

@RestController
@CrossOrigin("*")
public class CartItemsController {
	
	@Autowired
	CartItemsService cartItemserv;
	
	@GetMapping("/getAllcartItems")
	public List<CartItems> getAllItems()
	{
		return cartItemserv.getAllCartItems();
	}
	
	@PostMapping("/saveCartItem/{quantity}/{uid}")
	public CartItems saveItem(@RequestBody Item item,@PathVariable int quantity,@PathVariable int uid)
	{
		CartItems c=new CartItems();
		c.setImage(item.getiImage());
		c.setName(item.getIname());
		c.setPrice(item.getIprice());
		c.setU_id(uid);
		c.setIid(item.getiId());
		c.setQuantity(quantity);
		
		System.out.println(c);
		int i=cartItemserv.getcartItemByUidAndIid(c.getUid(), c.getIid());
		if(i!=0) {
			System.out.println("already Exist");
			int j= cartItemserv.updatecartitemsbyqty(c.getQuantity(),c.getPrice(), c.getIid(), c.getUid())	;
			return c;
		}else {
			System.out.println("Not Exist");
			c.setTotal(quantity*item.getIprice());
			return cartItemserv.saveCartItems(c);	
		}
		
	}
	
	@DeleteMapping("/deleteCartItem/{id}")
	public String deleteItem(@PathVariable int id)
	{
		return cartItemserv.deleteCartItems(id);
	}
	
	@PutMapping("/updateCartItem")
	public CartItems updateItem(@RequestBody CartItems CartItems)
	{
		return cartItemserv.updatecartItems(CartItems);
	}
	
	@GetMapping("/getCartItemById/{id}")
	public Optional<CartItems> getSingleItem(@PathVariable int id)
	{
		return cartItemserv.getSingleCartItem(id);
	}
	
	@GetMapping("/getCartItemByUid/{uid}")
	public List<CartItems> getCartItemsbyuid(@PathVariable int uid)
	{
		return cartItemserv.getcartItemsByUid(uid);
	}
	
	@GetMapping("/getCartTotal/{uid}")
	public double getCartItemsTotal(@PathVariable int uid)
	{
		double d=0;
		 List<CartItems> c=cartItemserv.getcartItemsByUid(uid);
		 d=c.stream().map(j->j.getTotal()).reduce(0.0d, (sum,total)->sum+total);
		 System.out.println("Total is "+d);
		return d;
	}
	
	@DeleteMapping("/deletecartbyuid/{uid}")
	public int deleteCartByUid(@PathVariable int uid) {
		
		return cartItemserv.deletecartItemsByUid(uid);
	}
	

}
