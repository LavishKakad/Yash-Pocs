package com.yash.fos.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Item {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int iId;
	private String iname;
	private double iprice;
	private String iImage;
	private boolean isdeleted;
	
	
	public int getiId() {
		return iId;
	}
	public void setiId(int iId) {
		this.iId = iId;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public double getIprice() {
		return iprice;
	}
	public void setIprice(double iprice) {
		this.iprice = iprice;
	}
	public String getiImage() {
		return iImage;
	}
	public void setiImage(String iImage) {
		this.iImage = iImage;
	}
	
	

	public boolean isIsdeleted() {
		return isdeleted;
	}
	public void setIsdeleted(boolean isdeleted) {
		this.isdeleted = isdeleted;
	}
	@Override
	public String toString() {
		return "Item [iId=" + iId + ", iname=" + iname + ", iprice=" + iprice + ", iImage=" + iImage + "]";
	}
	
	

}
