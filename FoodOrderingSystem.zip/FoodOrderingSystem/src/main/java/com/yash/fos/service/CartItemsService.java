package com.yash.fos.service;

import java.util.List;
import java.util.Optional;

import com.yash.fos.model.CartItems;



	public interface CartItemsService {

	public List<CartItems> getAllCartItems();

	public CartItems saveCartItems(CartItems Cartitem);

	public String deleteCartItems(int id);

	public CartItems updatecartItems(CartItems user);

	public Optional<CartItems> getSingleCartItem(int id);
	
	public List<CartItems> getcartItemsByUid(int uid);
	
	
	public int getcartItemByUidAndIid(int uid, int iid);
	
	public int updatecartitemsbyqty(int quantity,double price,int iid,int uid);
	
	public int deletecartItemsByUid(int uid);
	
	

}
