package com.yash.fos.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.fos.model.CartItems;
import com.yash.fos.model.Item;
import com.yash.fos.repository.CartItemsRepository;
import com.yash.fos.repository.ItemRepository;

@Service
public class CartItemsSeviceImpl implements CartItemsService {
	
	@Autowired
	CartItemsRepository CartItemrepo;

	@Override
	public List<CartItems> getAllCartItems() {
		
		return CartItemrepo.findAll();
	}

	@Override
	public CartItems saveCartItems(CartItems Cartitem) {
		
		return CartItemrepo.save(Cartitem);
	}

	@Override
	public String deleteCartItems(int id) {
		
		CartItemrepo.deleteById(id);
		 return "Item having Id "+id+" deleted successfully";
	}

	@Override
	public CartItems updatecartItems(CartItems Cartitem) {
		
		return CartItemrepo.save(Cartitem);
	}

	@Override
	public Optional<CartItems> getSingleCartItem(int id) {
		
		return CartItemrepo.findById(id);
	}

	@Override
	public List<CartItems> getcartItemsByUid(int uid) {
		
		return CartItemrepo.findByUid(uid);
	}

	@Override
	public int getcartItemByUidAndIid(int uid, int iid) {
		System.out.println(uid+" "+iid);
		
		return CartItemrepo.findByIidAndUid(iid, uid);
	}

	@Override
	public int updatecartitemsbyqty(int quantity,double price,int iid,int uid) {
		// TODO Auto-generated method stub
		return CartItemrepo.updateQtyAndPrice(quantity,price,iid,uid);
	}

	@Override
	public int deletecartItemsByUid(int uid) {
		// TODO Auto-generated method stub
		return CartItemrepo.deleteCartByUid(uid);
	}

	

}
