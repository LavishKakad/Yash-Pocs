package com.yash.fos.service;

import java.util.List;
import java.util.Optional;

import com.yash.fos.model.User;

public interface UserService {
	
	public List<User> getAllData();
	
	public User saveUser(User user);
	
	public String deleteUser(int id);
	
	public Optional<User> getUserById(int id);

	public User updateUser(User user);

	public User showPerticularUser(String uname, String upassword);

}
