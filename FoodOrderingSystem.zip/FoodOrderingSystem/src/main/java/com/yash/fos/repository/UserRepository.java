package com.yash.fos.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yash.fos.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{
	public User findByUnameAndUpassword(String uname, String upassword);

}
