package com.yash.fos.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.yash.fos.model.CartItems;
import com.yash.fos.model.Item;

@Repository
public interface CartItemsRepository extends JpaRepository<CartItems, Integer> {
	
	public List<CartItems> findByUid(int uid);

	@Query("select count(*) from CartItems where Iid=?1 and uid=?2")
	int findByIidAndUid(int iid,int uid);
	
	@Modifying
	@Transactional
	@Query("update CartItems i set i.quantity=i.quantity+?1,i.total=i.total+?1*?2 where iid=?3 and uid=?4")
	int updateQtyAndPrice(int quantity,double price,int iid,int uid);
	
	@Modifying
	@Transactional
	@Query("delete from CartItems where uid=?1")
	int deleteCartByUid(int uid);

}
