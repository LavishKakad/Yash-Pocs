package com.yash.fos.service;

import java.util.List;
import java.util.Optional;

import com.yash.fos.model.Item;

	public interface ItemService {

	public List<Item> getAllItem();

	public Item saveItem(Item item);

	public String deleteItem(int id);

	public Item updateItem(Item item);

	public Optional<Item> getSingleItem(int id);

}
