package com.yash;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

public class ItemDao {
	
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
		
	public List<Item> getItemByROWMap()
	  {
		  String query="select * from item inner join itemcategory on item.catId=itemcategory.catId";
		  
		  return jdbcTemplate.query(query, new RowMapper<Item>() {
			  public Item mapRow(ResultSet rs,int rownumber) throws SQLException{
				  
				  Item i= new Item();
				  ItemCategory ic =new ItemCategory();
				  
				  i.setItemId(rs.getInt("itemId"));
				  i.setItemName(rs.getString("itemName"));
				  i.setItemPrice(rs.getDouble("itemPrice"));
				  i.setCatId(rs.getInt("catId"));
				  ic.setCategoryType(rs.getString("categoryType"));
				  return i;
			}
			  		  
		  });
	  }
	
		
		  public int save(Item i) { String
		  query="insert into item values('"+i.getItemId()+"','"+i.getItemName()+"','"+i
		  .getItemPrice()+"','"+i.getCatId()+"')"; 
		  int r = jdbcTemplate.update(query);
		  return r; }
		  
		  
		  
		  
		
		
		  int updateItem(Item objI) { String query
		  ="update item set itemName='"+objI.getItemName()+"',itemPrice="+objI.
		  getItemPrice()+" where itemId="+objI.getItemId();
		  
		  return jdbcTemplate.update(query); }
		 
		  
		  
		  int delItem(int itemId) { String
		  query="delete from item where itemId="+itemId;
		  System.out.println("record successfully deleted...");
		  return jdbcTemplate.update(query); }
		 
		 
}
