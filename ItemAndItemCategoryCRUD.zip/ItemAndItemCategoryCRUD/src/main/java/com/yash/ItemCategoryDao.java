package com.yash;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

public class ItemCategoryDao {
	
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public List<ItemCategory> getItemCatByROWMap()
	  {
		  String query="select * from itemcategory";
		  
		  return jdbcTemplate.query(query, new RowMapper<ItemCategory>() {
			  public ItemCategory mapRow(ResultSet rs,int rownumber) throws SQLException{
				  
				  //Item i= new Item();
				  ItemCategory ic =new ItemCategory();
				 ic.setCatId(rs.getInt("catId"));
				  ic.setCategoryType(rs.getString("categoryType"));
				  return ic;
			}
			  		  
		  });
	  }
	
	  public int savecategory(ItemCategory ic) { 
		  
		  String query="insert into itemcategory values('"+ic.getCatId()+"','"+ic.getCategoryType()+"')"; 
		  int r = jdbcTemplate.update(query);
		  return r; }
		
	

}
//categeory table catid catname
//item table itemid itemname catid price 