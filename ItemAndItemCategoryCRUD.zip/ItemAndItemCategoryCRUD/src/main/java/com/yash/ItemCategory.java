package com.yash;

public class ItemCategory {
	
	private int catId;
	private String categoryType;
	
	public int getCatId() {
		return catId;
	}
	public void setCatId(int catId) {
		this.catId = catId;
	}
	public String getCategoryType() {
		return categoryType;
	}
	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}
	@Override
	public String toString() {
		return "ItemCategory [catId=" + catId + ", categoryType=" + categoryType + "]";
	}
	
	
	
	
	

}
