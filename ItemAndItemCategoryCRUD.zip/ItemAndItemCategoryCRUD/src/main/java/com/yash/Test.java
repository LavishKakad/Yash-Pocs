package com.yash;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		ItemDao itemDao = ctx.getBean("DAOBJ",ItemDao.class);
		ItemCategoryDao itemCategoryDao = ctx.getBean("ICOBJ",ItemCategoryDao.class);
		
		 Item item = new Item();
		 ItemCategory icc=new ItemCategory();
		
		Scanner sc = new Scanner(System.in);
		while(true)
		{
		System.out.println("Press 1. Show All Records....");
		System.out.println("Press 2. insert Item Record....");
		System.out.println("Press 3. insert Item Category Record....");
		System.out.println("Press 4. Update Item....");
		System.out.println("Press 5. delete Item....");
		int no=sc.nextInt();
		switch(no)
		{
		case 1:

			
			  List<Item> leobj=itemDao.getItemByROWMap(); List<ItemCategory>
			  ic=itemCategoryDao.getItemCatByROWMap();
			  System.out.println("ITEM CATEGORY---"); for(ItemCategory icc1 : ic)
			  System.out.println(+icc1.getCatId()+" "+icc1.getCategoryType());
			  System.out.println(
			  "--------------------------------------------------------------------------------------------"
			  );
			  
			  for(Item i:leobj)
			  
			  System.out.println("Item Id :- "+i.getItemId()+"| Item Name :- "+i.
			  getItemName()+"| Item Price :- "+i.getItemPrice()+"| Item Category No :-"
			  +i.getCatId());
			 
		break;

		case 2:
			System.out.println("enter item id");
			int idd=sc.nextInt();
			 item.setItemId(idd); 
			 
			 System.out.println("enter item name");
				String Iname=sc.next();
			 item.setItemName(Iname);
			 
			 System.out.println("enter item price");
				double Iprice = sc.nextDouble();
			  item.setItemPrice(Iprice); 
			  
			  System.out.println("Category Id should check before enter in show all record");
			  System.out.println("enter category id");
			  int catid=sc.nextInt();
			  item.setCatId(catid);
			  
			  System.out.println("no of record inserted "+itemDao.save(item));
			 
		break;

		case 3:

			System.out.println("enter category id");
			int cid=sc.nextInt();
			icc.setCatId(cid);
			System.out.println("enter category Type");
			String cname=sc.next();
			icc.setCategoryType(cname);
			  
			  System.out.println("no of record inserted "+itemCategoryDao.savecategory(icc));
		break;

		case 4:
			
			System.out.println("enter which id record is updated");
			int id=sc.nextInt();
			item.setItemId(id);
			System.out.println("enter item name");
			String name=sc.next();
			item.setItemName(name);
			System.out.println("enter item price");
			double price = sc.nextDouble();
			item.setItemPrice(price);
			
			System.out.println("no of record updated "+itemDao.updateItem(item));
			
		break;

		case 5:
			System.out.println("Enter id which u want to delete");
			int id1=sc.nextInt();
			itemDao.delItem(id1);
			break;

		default:
		System.out.println("Enter correct No");

		}
		System.out.println("----------------------------------------------------------------------------------");
	}

	}
}
