package com.yash.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.yash.mapper.ProductMapper;
import com.yash.model.Product;

@Repository
public class ProductDaoImpl implements ProductDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public List<Product> getAllProduct() {
		String sql="select * from product";
		System.out.println("inside get all");
		return jdbcTemplate.query(sql, new ProductMapper());
	}

	@Override
	public Product getProductById(int id) {
		
		String sql="select * from product where product_id="+id+" ";
		
		return jdbcTemplate.queryForObject(sql, new ProductMapper());
	}

	@Override
	public List<Product> getProductByCategory(String cat) {
		String sql="select * from product where category='"+cat+"' ";
		
		return jdbcTemplate.query(sql, new ProductMapper());
	}

	@Override
	public void InsertProduct(Product p) {
		String sql="insert into product(product_id,category,description,manufacturer,name,unit_price) values(?,?,?,?,?,?)";
		
		jdbcTemplate.update(sql, new PreparedStatementSetter()
				{

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {
						ps.setString(1, p.getProductId());
						ps.setString(2, p.getCategory());
						ps.setString(3, p.getDescription());
						ps.setString(4, p.getManufacturer());
						ps.setString(5, p.getName());
						ps.setInt(6, p.getUnitPrice());
						
					}
			
				});
		
	}

}
