package com.yash.controller;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.yash.model.Product;
import com.yash.service.ProductService;

@Controller
public class HomeController {

	@Autowired
	ProductService pserv;
	
	@RequestMapping(method = RequestMethod.GET , value = "/hello")
	public String getProduct(ModelMap model)
	{
		model.addAttribute("products", pserv.getAllProduct());
		return "first";
	}
	
	@RequestMapping(method = RequestMethod.GET , value = "/getProductbyId")
	public String getProductById(ModelMap model,@RequestParam int id)
	{
		model.addAttribute("product", pserv.getProductById(id));
		return "getProductbyId";
	}
	@RequestMapping(method = RequestMethod.GET , value = "/getProductbycategory/{cat}")
	public String getProductByCategory(ModelMap model,@PathVariable String cat)
	{
		model.addAttribute("getProductbycategory", pserv.getProductByCategory(cat));
		return "getProductbyCategory";
	}
	
	@RequestMapping(method = RequestMethod.GET , value = "/addProduct")
	public String getProductAddForm(ModelMap model)
	{
		model.addAttribute("newProduct", new Product());
		return "addProduct";
	}
	
	@RequestMapping(method = RequestMethod.POST , value = "/addProduct")
	public String addProduct(@ModelAttribute("newProduct") Product product)
	{
		pserv.InsertProduct(product);
		return "redirect:/hello";
	}
}
