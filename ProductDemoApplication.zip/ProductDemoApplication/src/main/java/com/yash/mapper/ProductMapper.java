package com.yash.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.model.Product;

public class ProductMapper implements RowMapper<Product>{

	@Override
	public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
		Product p=new Product();
		p.setProductId(rs.getString(1));
		p.setName(rs.getString(2));
		p.setCategory(rs.getString(3));
		p.setDescription(rs.getString(4));
		p.setManufacturer(rs.getString(5));
		p.setUnitPrice(rs.getInt(6));
		return p;
	}

}
