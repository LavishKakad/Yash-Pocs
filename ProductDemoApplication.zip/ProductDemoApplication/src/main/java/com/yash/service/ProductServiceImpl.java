package com.yash.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.model.Product;
import com.yash.repository.ProductDao;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao pdao;

	@Override
	public List<Product> getAllProduct() {

		return pdao.getAllProduct();
	}

	@Override
	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		return pdao.getProductById(id);
	}

	 

	
	
	  @Override public List<Product> getProductByCategory(String cat) { 
	  return pdao.getProductByCategory(cat); 
	  //return pdao.getAllProduct().stream().filter(p->p.getCategory().equals(cat)).collect(Collectors.toList());
	  
	  }

	@Override
	public void InsertProduct(Product p) {
		pdao.InsertProduct(p);
		
	}
	 
	  
	 

}
