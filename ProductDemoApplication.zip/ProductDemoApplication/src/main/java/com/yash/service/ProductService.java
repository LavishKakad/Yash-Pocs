package com.yash.service;

import java.util.List;


import com.yash.model.Product;


public interface ProductService {
	
	public List<Product> getAllProduct();
	
	public Product getProductById(int id);
	
	public List<Product> getProductByCategory(String cat);
	
	public void InsertProduct(Product p);

}
